var TABS = {};

// monitor page refresh
chrome.extension.onConnect.addListener(function (port) {
    //when devtools-page connects (when App Inspector is actually opened)
    if (port.name === 'DevTool') {

        chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
            if (changeInfo.status === 'complete') {
                var oldUrl = TABS[tabId],
                    hashLocation, hash, newTab;

                //cache the URL so we can compare it later
                if (!oldUrl || tab.url !== oldUrl.url) {
                    newTab = {
                        url: tab.url,
                        hash: ''
                    };

                    hashLocation = tab.url.indexOf('#');

                    if (hashLocation) {
                        newTab.hash = tab.url.substr(hashLocation + 1);
                    }

                    TABS[tabId] = newTab;
                }

                if (oldUrl) {
                    hashLocation = tab.url.indexOf('#');

                    hash = (hashLocation) ? tab.url.substr(hashLocation + 1) : '';

                    //don't refresh the page if only the hash changes
                    if (hash && oldUrl.hash !== hash) {
                        TABS[tabId].hash = hash;
                    }
                    //if the hash has not changed, assume the user has manually refreshed the browser
                    else {
                        port.postMessage({
                            tabId: tabId,
                            message: 'refreshed!'
                        });
                    }
                }

            }
        });

    }
});
