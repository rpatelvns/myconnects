var elementsPanel = chrome.devtools.panels.elements;
var pageComponent = function pageComponent() {
    var cmp, data, xtype;

    if (window.Ext) {
        cmp = Ext.getCmp($0.id);

        if (cmp) {
            data = Object.create(null);

            // class name
            if (Ext.getClassName) {
                ref = Ext.getClassName(cmp);
            }

            // xtype
            xtype = cmp.xtype || (cmp.getXType ? cmp.getXType() : '');

            if (xtype) {
                ref += ' (' + xtype + ')';
            }

            if (!ref) {
                ref = '#' + cmp.id;
            }

            data[ref] = cmp;
        }
    }

    return data;
};

elementsPanel.createSidebarPane('ExtJS Component', function (sidebar) {
    var onSelectionChanged = function () {
        sidebar.setExpression('(' + pageComponent.toString() + ')()');
    };

    onSelectionChanged();

    elementsPanel.onSelectionChanged.addListener(onSelectionChanged);
});
