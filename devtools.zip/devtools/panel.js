var AI = {
    isReady: false,
    contextMenu: null
};

chrome.devtools.panels.create(
    'ExtJS DevTool',
    'resources/images/panel_icon.png',
    'DevTool/index.html',

    function (senchaPanel) {
        senchaPanel.onShown.addListener(function (panelWindow) {
            if (AI.isReady) {
                return;
            }

            AI.isReady = true;

            var tabId = chrome.devtools.inspectedWindow.tabId;

            //connect to logic in background.js
            var port = chrome.runtime.connect({
                name: 'DevTool'
            });

            //when messages are received from background.js
            port.onMessage.addListener(function (msg) {
                if (msg.tabId === tabId) {
                    panelWindow.location.reload(true);
                }
            });
        });
    }
);
