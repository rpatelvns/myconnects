const jsdom = require("./bundle");
const { JSDOM } = jsdom;

var dom = new JSDOM();

console.log(dom);
