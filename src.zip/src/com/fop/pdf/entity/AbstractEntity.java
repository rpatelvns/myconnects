package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public abstract class AbstractEntity implements EntityInterface {
	protected EntityType entityType;
	
	public AbstractEntity(EntityType type) {
        setEntityType(type);
    }

	public EntityType getEntityType() {
		return entityType;
	}

	public void setEntityType(EntityType entityType) {
		this.entityType = entityType;
	}
}
