package com.fop.pdf.entity;

public class Block extends BlockEntity {

}
