package com.fop.pdf.entity;

public class BlockEntity extends AbstractEntity{

}
