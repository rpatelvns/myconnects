package com.fop.pdf.entity;

public class Container extends BlockEntity {

}
