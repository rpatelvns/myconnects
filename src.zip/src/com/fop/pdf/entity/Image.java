package com.fop.pdf.entity;

public class Image extends InlineEntity {

}
