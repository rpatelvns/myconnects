package com.fop.pdf.entity;

public class InlineEntity extends AbstractEntity{

}
