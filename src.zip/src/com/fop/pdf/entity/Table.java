package com.fop.pdf.entity;

public class Table extends BlockEntity {

}
