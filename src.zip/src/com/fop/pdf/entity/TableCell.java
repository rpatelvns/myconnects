package com.fop.pdf.entity;

public class TableCell extends BlockEntity {

}
