package com.fop.pdf.entity;

public class TableColumn extends BlockEntity {

}
