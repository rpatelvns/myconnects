package com.fop.pdf.entity;

public class TableRow extends BlockEntity {

}
