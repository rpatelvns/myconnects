package com.fop.pdf.generator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fop.pdf.entity.AbstractEntity;

public class EntityFactory {
	public AbstractEntity createEntity(JsonNode jsonNode) {
		String type = (String)jsonNode.get("type");

		
	}
}
