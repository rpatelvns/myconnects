import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fop.pdf.entity.AbstractEntity;
import com.fop.pdf.generator.EntityFactory;
import com.github.jknack.handlebars.Handlebars;
import com.github.jknack.handlebars.Template;

public class Test {
	public static void main(String[] args) {
		File file = new File("templates/print.json");
		JsonFactory jsonFactory = new JsonFactory();
		ObjectMapper mapper = new ObjectMapper(jsonFactory);
		
		try {
			//Handlebars handlebars = new Handlebars();
			//Template tpl = handlebars.compileInline("Hello {{this}}!");
			//System.out.println(tpl.apply("Handlebars.java"));
			
			JsonNode rootNode = mapper.readTree(file);
			Iterator<Map.Entry<String, JsonNode>> fields = rootNode.fields();
			StringBuffer template = new StringBuffer();
			
			while (fields.hasNext()) {
			    Map.Entry<String, JsonNode> entry = fields.next();
			    AbstractEntity entity = EntityFactory.createEntity(entry.getValue());
			    
			    if(entity != null) {
			    	template.append(entity.getFOPXML());
			    }
			
			}
			
			System.out.println("final template" + template);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
