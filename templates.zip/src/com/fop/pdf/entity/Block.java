package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class Block extends BlockEntity {
	public Block(EntityType type) {
		super(type);
	}
}
