package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class BlockEntity extends AbstractEntity{
	public BlockEntity(EntityType type) {
		super(type);
	}

	@Override
	public String getFOPXML() {
		return null;
	}
}
