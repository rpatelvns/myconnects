package com.fop.pdf.entity;

public interface EntityInterface {
	public String getFOPXML();
}
