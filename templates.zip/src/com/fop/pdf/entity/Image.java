package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class Image extends InlineEntity {
	public Image(EntityType type) {
		super(type);
	}
}
