package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class InlineEntity extends AbstractEntity{
	public InlineEntity(EntityType type) {
		super(type);
	}

	@Override
	public String getFOPXML() {
		return null;
	}
}
