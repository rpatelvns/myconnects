package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class List extends BlockEntity {
	public List(EntityType type) {
		super(type);
	}
}
