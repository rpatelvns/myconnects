package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class ListItem extends BlockEntity {
	public ListItem(EntityType type) {
		super(type);
	}
}
