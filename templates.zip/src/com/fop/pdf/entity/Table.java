package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class Table extends BlockEntity {
	public Table(EntityType type) {
		super(type);
	}
}
