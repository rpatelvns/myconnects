package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class TableCell extends BlockEntity {
	public TableCell(EntityType type) {
		super(type);
	}
}
