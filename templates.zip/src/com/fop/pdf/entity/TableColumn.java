package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class TableColumn extends BlockEntity {
	public TableColumn(EntityType type) {
		super(type);
	}
}
