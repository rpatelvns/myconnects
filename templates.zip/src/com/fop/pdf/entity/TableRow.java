package com.fop.pdf.entity;

import com.fop.pdf.generator.EntityType;

public class TableRow extends BlockEntity {
	public TableRow(EntityType type) {
		super(type);		
	}
}
