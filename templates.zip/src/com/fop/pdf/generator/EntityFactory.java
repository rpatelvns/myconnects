package com.fop.pdf.generator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fop.pdf.entity.AbstractEntity;

public class EntityFactory {
	public static AbstractEntity createEntity(JsonNode jsonNode) {
		JsonNode  typeNode = jsonNode.get("type");
		if(typeNode != null) {
			typeNode.asText();
		}
		
		return null;
	}
}
