package com.fop.pdf.generator;

import java.util.HashMap;
import java.util.Map;

public enum EntityType {
	TABLE("table"), 
	TABLE_ROW("tableRow"), 
	TABLE_COLUMN("tableColumn"), 
	TABLE_CELL("tableCell"), 
	BLOCK("block"), 
	CONTAINER("container"), 
	LIST("list"), 
	IMAGE("image"), 
	INLINE("inline");

	private String type;
	private static final Map<String, EntityType> lookup = new HashMap<String, EntityType>();

	EntityType(String type) {
		this.type = type;
	}

	static {
		for (EntityType type : EntityType.values()) {
			lookup.put(type.getType(), type);
		}
	}

	public static EntityType get(String type) {
		return lookup.get(type);
	}

	public String getType() {
		return type;
	}
}
